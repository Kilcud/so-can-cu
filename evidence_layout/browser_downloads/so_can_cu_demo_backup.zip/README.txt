SỔ CĂN CỨ — BẢN SAO LƯU

Tệp so_can_cu.sqlite3 là bản sao nhất quán tạo bằng SQLite backup API.
Chạy python tools/verify_backup.py <tep.zip> trước khi dùng. Dừng ứng dụng trước khi phục hồi thủ công vào thư mục dữ liệu mới. Giữ bản gốc cho đến khi kiểm tra xong. Không có chức năng tự ghi đè dữ liệu đang sử dụng.
Mã SHA-256 phát hiện thay đổi so với bản kê, không phải chữ ký số hay chứng nhận nguồn gốc.
